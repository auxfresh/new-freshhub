document.addEventListener('DOMContentLoaded', () => {
    const video = document.getElementById('livePlayer');
    const message = document.getElementById('noStreamMessage');
    const playOverlay = document.querySelector('.play-overlay');
    const playIcon = document.querySelector('.play-icon');
    const progressBarFill = document.querySelector('.progress-bar-fill');
    const progressBarThumb = document.querySelector('.progress-bar-thumb');
    const progressBarTrack = document.querySelector('.progress-bar-track');
    const currentTimeSpan = document.querySelector('.current-playback-time');
    const totalTimeSpan = document.querySelector('.total-playback-time');
    const followButton = document.querySelector('.follow-button');
    const videoPlayerContainer = document.querySelector('.video-player-container');

    // Livestream URL - replace with your actual stream URL if different
    const streamUrl = "https://livepeercdn.studio/hls/b314kwd1heh1hpu2/index.m3u8";

    function showMessage() {
      video.style.display = "none";
      playOverlay.style.display = "none"; // Hide play overlay too
      message.style.display = "flex"; // Use flex to center message
      // Hide progress bar and times
      progressBarTrack.style.display = "none";
      currentTimeSpan.style.display = "none";
      totalTimeSpan.style.display = "none";
    }

    function showVideo() {
      video.style.display = "block";
      playOverlay.style.display = "flex"; // Show play overlay
      message.style.display = "none";
      // Show progress bar and times
      progressBarTrack.style.display = "flex";
      currentTimeSpan.style.display = "block";
      totalTimeSpan.style.display = "block";
    }

    // --- HLS.js Integration for Livestreaming ---
    if (Hls.isSupported()) {
      const hls = new Hls();
      hls.loadSource(streamUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, function () {
        showVideo();
        video.play();
      });

      hls.on(Hls.Events.ERROR, function (event, data) {
        console.error("HLS.js error:", data);
        if (data.fatal) {
          switch(data.type) {
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            case Hls.ErrorTypes.NETWORK_ERROR:
              console.warn("Network error, trying to load source again...");
              hls.loadSource(streamUrl); // Attempt to reload
              break;
            default:
              showMessage(); // For other fatal errors, show message
              hls.destroy();
              break;
          }
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native HLS support for Safari/iOS
      video.src = streamUrl;

      video.addEventListener('loadedmetadata', function () {
        showVideo();
        video.play();
      });

      video.addEventListener('error', function () {
        console.error("Native HLS playback error.");
        showMessage();
      });
    } else {
      showMessage(); // Browser does not support HLS
    }


    // --- Video Playback Controls (still relevant for standard HTML5 video API) ---
    // The play/pause toggle for the overlay still works with the video element itself
    playOverlay.addEventListener('click', () => {
        if (video.paused) {
            video.play();
            videoPlayerContainer.classList.remove('paused');
        } else {
            video.pause();
            videoPlayerContainer.classList.add('paused');
        }
    });

    video.addEventListener('play', () => {
        playIcon.classList.remove('fa-play');
        playIcon.classList.add('fa-pause');
        videoPlayerContainer.classList.remove('paused');
    });

    video.addEventListener('pause', () => {
        playIcon.classList.remove('fa-pause');
        playIcon.classList.add('fa-play');
        videoPlayerContainer.classList.add('paused');
    });

    video.addEventListener('timeupdate', () => {
        const currentTime = video.currentTime;
        const duration = video.duration; // For live streams, duration might be Infinity or 0

        if (!isNaN(duration) && isFinite(duration) && duration > 0) {
            const progressPercent = (currentTime / duration) * 100;
            progressBarFill.style.width = `${progressPercent}%`;
            progressBarThumb.style.left = `${progressPercent}%`;

            currentTimeSpan.textContent = formatTime(currentTime);
            totalTimeSpan.textContent = formatTime(duration);
        } else {
            // Handle live stream where duration is not a fixed number
            currentTimeSpan.textContent = 'LIVE'; // Or just the current time
            totalTimeSpan.textContent = ''; // No total time for live
            progressBarFill.style.width = '100%'; // Show full bar for live
            progressBarThumb.style.left = '100%';
        }
    });

    // Handle clicking on the progress bar to seek (may not be applicable for all live streams)
    progressBarTrack.addEventListener('click', (e) => {
        if (!isNaN(video.duration) && isFinite(video.duration) && video.duration > 0) {
            const clickX = e.offsetX; // X position of the click relative to the track
            const trackWidth = progressBarTrack.clientWidth;
            const seekTime = (clickX / trackWidth) * video.duration;
            video.currentTime = seekTime;
        }
    });

    // Helper function to format time (MM:SS)
    function formatTime(seconds) {
        if (isNaN(seconds) || !isFinite(seconds)) return '0:00'; // Handle non-finite duration

        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = Math.floor(seconds % 60);
        return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
    }


    // --- Follow Button ---
    followButton.addEventListener('click', () => {
        if (followButton.textContent === 'Subscribe') {
            followButton.textContent = 'Subscribed';
            followButton.style.backgroundColor = '#555'; /* Change color when followed */
            followButton.style.color = '#fff';
            followButton.style.border = '1px solid #777';
        } else {
            followButton.textContent = 'Subscribe';
            followButton.style.backgroundColor = '#4d2e6b';
            followButton.style.color = 'white';
            followButton.style.border = 'none';
        }
    });

    // Initial state check for play overlay
    if (video.paused || video.readyState < 3) { // If video is paused or not ready
        videoPlayerContainer.classList.add('paused');
    } else {
        videoPlayerContainer.classList.remove('paused');
    }

    // Initialize to show message until stream loads
    showMessage();
});
