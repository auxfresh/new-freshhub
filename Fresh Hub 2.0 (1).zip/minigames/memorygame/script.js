const board = document.getElementById("game-board");
const startButton = document.getElementById("startButton");
const themeSelect = document.getElementById("themeSelect");
const difficultySelect = document.getElementById("difficulty");
const movesCount = document.getElementById("moves");
const matchesCount = document.getElementById("matches");
const timerDisplay = document.getElementById("timer");

let firstCard, secondCard;
let lockBoard = false;
let matchedPairs = 0;
let moves = 0;
let totalPairs = 6;
let timer, seconds = 0;

const themes = {
  fruits: ["🍎", "🍌", "🍇", "🍉", "🍒", "🍍", "🥝", "🥭"],
  vehicles: ["🚗", "🚌", "🚑", "🚒", "🚜", "🚁", "✈️", "🚀"],
  animals: ["🐶", "🐱", "🐭", "🦊", "🐼", "🐸", "🐵", "🦁"],
  flags: ["🇺🇸", "🇬🇧", "🇳🇬", "🇫🇷", "🇯🇵", "🇨🇦", "🇰🇷", "🇧🇷"]
};

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

function updateTimer() {
  timerDisplay.textContent = `${seconds}s`;
}

function flipCard(card) {
  if (lockBoard || card === firstCard || card.classList.contains("flipped")) return;

  card.classList.add("flipped");
  playSound("flip");

  if (!firstCard) {
    firstCard = card;
    return;
  }

  secondCard = card;
  moves++;
  movesCount.textContent = moves;

  const isMatch = firstCard.querySelector(".front").textContent === secondCard.querySelector(".front").textContent;

  if (isMatch) {
    matchedPairs++;
    matchesCount.textContent = matchedPairs;
    playSound("match");
    resetTurn();
    if (matchedPairs === totalPairs) {
      playSound("win");
      clearInterval(timer);
      setTimeout(() => alert("🎉 You won!"), 300);
    }
  } else {
    lockBoard = true;
    playSound("wrong");
    setTimeout(() => {
      firstCard.classList.remove("flipped");
      secondCard.classList.remove("flipped");
      resetTurn();
    }, 1000);
  }
}

function resetTurn() {
  [firstCard, secondCard] = [null, null];
  lockBoard = false;
}

function startGame() {
  clearInterval(timer);
  seconds = 0;
  updateTimer();

  board.innerHTML = "";
  firstCard = null;
  secondCard = null;
  lockBoard = false;
  matchedPairs = 0;
  moves = 0;

  movesCount.textContent = "0";
  matchesCount.textContent = "0";

  totalPairs = Number(difficultySelect.value) || 6;

  const theme = themeSelect.value;
  const icons = themes[theme].slice(0, totalPairs);
  const gameIcons = shuffle([...icons, ...icons]);

  gameIcons.forEach(icon => {
    const card = document.createElement("div");
    card.classList.add("card");
    card.innerHTML = `
      <div class="front">${icon}</div>
      <div class="back">?</div>
    `;
    card.addEventListener("click", () => flipCard(card));
    board.appendChild(card);
  });

  timer = setInterval(() => {
    seconds++;
    updateTimer();
  }, 1000);
}

function playSound(type) {
  const soundMap = {
    flip: "sounds/flip.mp3",
    match: "sounds/match.mp3",
    wrong: "sounds/wrong.mp3",
    win: "sounds/win.mp3"
  };
  const sound = new Audio(soundMap[type]);
  sound.play();
}

